# ArangoML FeatureStore

This is a simple package that provides machine learning applications the following capabilities:
1. Write machine learning features to an ArangoDB feature store
2. Read machine learning features from an ArangoDB feature store

